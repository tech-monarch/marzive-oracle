import os
import json
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
from tensorflow.keras.layers import Input, Embedding, LSTM, Dense, GlobalAveragePooling1D
from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

# Optional: For OpenAI API integration
import requests

OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')

# Load preprocessed data
def load_data(json_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    texts = [item['content'] for item in data]
    filenames = [item['filename'] for item in data]
    return texts, filenames

def build_tokenizer(texts, num_words=10000):
    tokenizer = Tokenizer(num_words=num_words, oov_token='<OOV>')
    tokenizer.fit_on_texts(texts)
    return tokenizer

def vectorize_texts(tokenizer, texts, maxlen=256):
    sequences = tokenizer.texts_to_sequences(texts)
    padded = pad_sequences(sequences, maxlen=maxlen, padding='post', truncating='post')
    return padded

def build_simple_retriever_model(vocab_size, embedding_dim=64, maxlen=256):
    inp = Input(shape=(maxlen,))
    x = Embedding(vocab_size, embedding_dim, input_length=maxlen)(inp)
    x = GlobalAveragePooling1D()(x)
    x = Dense(64, activation='relu')(x)
    out = Dense(1, activation='sigmoid')(x)
    model = Model(inputs=inp, outputs=out)
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model

# Optional: Use OpenAI API for question answering
def openai_answer(question, context):
    url = 'https://api.openai.com/v1/completions'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {OPENAI_API_KEY}'
    }
    prompt = f"Context: {context}\nQuestion: {question}\nAnswer:"
    data = {
        'model': 'text-davinci-003',
        'prompt': prompt,
        'max_tokens': 256,
        'temperature': 0.0
    }
    response = requests.post(url, headers=headers, json=data)
    if response.status_code == 200:
        return response.json()['choices'][0]['text'].strip()
    else:
        return f"OpenAI API error: {response.text}"

if __name__ == "__main__":
    data_path = os.path.join(os.path.dirname(__file__), 'prepared_documents.json')
    texts, filenames = load_data(data_path)
    print(f"Loaded {len(texts)} documents.")

    # Build tokenizer and vectorize texts
    tokenizer = build_tokenizer(texts)
    vocab_size = min(len(tokenizer.word_index) + 1, 10000)
    X = vectorize_texts(tokenizer, texts)

    # For demonstration, create dummy binary labels (e.g., relevant/not relevant)
    y = np.ones((len(texts), 1))

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = build_simple_retriever_model(vocab_size)
    model.summary()
    model.fit(X_train, y_train, epochs=5, batch_size=8, validation_data=(X_val, y_val))
    model.save('qa_retriever_model.h5')
    print("Model trained and saved as qa_retriever_model.h5")

    # Example: Use OpenAI API for QA
    example_question = "What is the Marzive DAO?"
    context = texts[0] if texts else ""
    answer = openai_answer(example_question, context)
    print(f"OpenAI Answer: {answer}")